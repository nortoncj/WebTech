<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.3
 */

?>
<script type="text/html" id="tmpl-fusion_woo_sorting-shortcode">
{{{ styles }}}
<div {{{ _.fusionGetAttributes( attr ) }}}>
	{{{ output }}}
</div>
</script>
