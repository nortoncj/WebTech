<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_woo_cart_table-shortcode">
	{{{styles}}}
	<table {{{ _.fusionGetAttributes( wooCartTable ) }}} cellspacing="0">
	{{{ cart_table }}}
	</table>
</script>
